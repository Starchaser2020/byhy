import os


def png_jpg(str):
    image = os.path.basename(str)

    pngB = b'\x89\x50\x4e\x47\x0d\x0a\x1a\x0a'
    imageB = image.encode()
    print(pngB,imageB)
    if imageB[0:8] == pngB:
        print('png')
    else:
        print('jpg')
